// Generated from the Excel-exported string table. Do not edit.
window.stageGameUiText = {"languages":[{"code":"ko","title":"한 수 진급","loading":"게임을 불러오는 중…","error":"게임을 불러올 수 없어요. 새로고침해 주세요.","canvasLabel":"한 수 진급 게임"},{"code":"en","title":"Rank by Rank","loading":"Loading game…","error":"Could not load the game. Please reload.","canvasLabel":"Rank by Rank game"}]};
