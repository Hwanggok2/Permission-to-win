# 군모 이미지 최신 선택본 — C06 표식 방향 수정

2026-10-15. 하사 최건우(C06)의 군모 표식을 **세 자세 모두 아래 방향 V**로 수정했다. 내장 ImageGen으로 기존 시트를 편집했으며 1536×1024 RGBA와 512×1024 셀 3개를 유지했다. C07~C18은 v1을 그대로 사용한다. 원본 v1 PNG와 ZIP은 보존한다.

[전체 13명 ZIP](../characters-caps-20261015-v2.zip) · [수정 프롬프트](generation.json) · [최신 파일·해시 목록](manifest.json)

게임 적용은 별도 대기 중이다. Client의 C06.png는 아직 v1 복사본이므로 적용 담당자는 아래 v2 PNG를 사용하고 Sprite 영역을 다시 계산해야 한다.

| ID | 이름·계급 | 현재 PNG |
| --- | --- | --- |
| C06 | 최건우 · 하사 | [C06-choi-geonwoo-cap-v2.png](C06-choi-geonwoo-cap-v2.png) |
| C07 | 한유진 · 공군 중사 | [C07-han-yujin-cap-v1.png](../characters-caps-20261015-v1/C07-han-yujin-cap-v1.png) |
| C08 | 박정민 · 상사 | [C08-park-jeongmin-cap-v1.png](../characters-caps-20261015-v1/C08-park-jeongmin-cap-v1.png) |
| C09 | 한태식 · 원사 | [C09-han-taesik-cap-v1.png](../characters-caps-20261015-v1/C09-han-taesik-cap-v1.png) |
| C10 | 배성훈 · 준위 | [C10-bae-seonghun-cap-v1.png](../characters-caps-20261015-v1/C10-bae-seonghun-cap-v1.png) |
| C11 | 김준서 · 소위 | [C11-kim-junseo-cap-v1.png](../characters-caps-20261015-v1/C11-kim-junseo-cap-v1.png) |
| C12 | 서지훈 · 소대장 | [C12-seo-jihoon-cap-v1.png](../characters-caps-20261015-v1/C12-seo-jihoon-cap-v1.png) |
| C13 | 장태오 · 중대장 | [C13-jang-taeo-cap-v1.png](../characters-caps-20261015-v1/C13-jang-taeo-cap-v1.png) |
| C14 | 서강현 · 작전참모 | [C14-seo-ganghyeon-cap-v1.png](../characters-caps-20261015-v1/C14-seo-ganghyeon-cap-v1.png) |
| C15 | 이도현 · 대대장 | [C15-lee-dohyeon-cap-v1.png](../characters-caps-20261015-v1/C15-lee-dohyeon-cap-v1.png) |
| C16 | 백승우 · 연대장 | [C16-baek-seungwoo-cap-v1.png](../characters-caps-20261015-v1/C16-baek-seungwoo-cap-v1.png) |
| C17 | 임재훈 · 부사단장 | [C17-lim-jaehoon-cap-v1.png](../characters-caps-20261015-v1/C17-lim-jaehoon-cap-v1.png) |
| C18 | 윤정호 · 사단장 | [C18-yoon-jeongho-cap-v1.png](../characters-caps-20261015-v1/C18-yoon-jeongho-cap-v1.png) |

## C06 수정본

![하사 최건우: 세 자세 모두 아래 방향 V](C:/Github/StageGame/Docs/Design/assets/characters-caps-20261015-v2/C06-choi-geonwoo-cap-v2.png)
